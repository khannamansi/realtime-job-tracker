# multi-db-query-parser
This repository consists of project for multi-db-query-parser.

To run the application type in the command in terminal: pip install -r requirements.txt
