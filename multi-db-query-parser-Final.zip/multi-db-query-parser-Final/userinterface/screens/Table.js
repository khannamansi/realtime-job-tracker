import React, { Component } from 'react';
import { StyleSheet, View, ScrollView } from 'react-native';
import { Table, TableWrapper, Row } from 'react-native-table-component';


export default class ResultTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tableHead: this.props.headers,
    }
  }

  componentDidMount(){
    if(this.props.headers != null){
      let oldState = ["S.No"];
      for(let i = 0; i < this.props.headers.length; i++){
        oldState.push(this.props.headers[i]);
      }
      this.setState({ tableHead: oldState });
    }
  }

  render() {
    const state = this.state;
    let widthArr = [80];
    for(let i = 0; i < this.state.tableHead.length -1; i++){
        widthArr.push(175);
    }
    let tableData = [];
    for(let i = 0; i < this.props.data.length; i++){
        let row = [i+1];
        for(let j = 1; j < this.state.tableHead.length; j++){
            row.push(this.props.data[i][this.state.tableHead[j]]);
        }
        tableData.push(row);
    }

    console.log(tableData);
    return (
      <View style={styles.container}>
        <ScrollView horizontal={true} keyboardShouldPersistTaps='never'>
            <View>
            <Table borderStyle={{borderColor: '#C1C0B9'}}>
                <Row data={state.tableHead} widthArr={widthArr} style={styles.head} textStyle={styles.headerText}/>
            </Table>
            <ScrollView style={styles.dataWrapper}>
                <Table borderStyle={{borderColor: '#C1C0B9'}}>
                {
                    tableData.map((dataRow, index) => (
                    <Row
                        key={index}
                        data={dataRow}
                        widthArr={widthArr}
                        style={[styles.row, index%2 && {backgroundColor: '#ffffff'}]}
                        textStyle={styles.text}
                    />
                    ))
                }
                </Table>
            </ScrollView>
            </View>
        </ScrollView>
      </View>
    )
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    paddingTop: 30,
    backgroundColor: '#ffffff' ,
    // width: '100%'
  },
  head: {
    height: 50,
    backgroundColor: '#FFC300'
  },
  text: {
    textAlign: 'center',
    fontWeight: '200'
  },
  headerText: {
    textAlign: 'center',
    fontWeight: 'bold'
  },
  dataWrapper: {
    marginTop: -1,
    // width: '100%'
  },
  row: {
    height: 50,
    backgroundColor: '#F7F8FA'
  }
});